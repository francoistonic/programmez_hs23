# Casse-Briques

Un jeu de casse briques développé à l'occasion d'une session de codage en ligne.

Soyez libres de vous inspirer de ce code pour créer vos propres casses briques et les republier sur GitHub ou ailleurs. Vous pouvez aussi vous inspirer des techniques évoquées lors du direct afin de développer vos propres jeux.

Ce projet a été développé en direct sur Twitch lors de la semaine du [Learn To Code Summer Camp 2021](https://apprendre-delphi.fr/learn-to-code-summer-camp-2021.php). Pour comprendre comment aboutir à ce projet en moins de 2 heures, vous pouvez suivre [la rediffusion de son développement](https://apprendre-delphi.fr/ltcsc2021-05.php).

Si la création de jeux vidéo vous intéresse, vous pouvez aussi regarder [les présentations et séries de vidéos](https://videos.apprendre-delphi.fr/w/p/jU3L7GkvEySdDmNwdyMVgt?playlistPosition=1) qui lui sont consacré.

## C'est quoi Delphi ? Où le télécharger ? Comment l'utiliser ?

Si vous ne connaissez pas Delphi et le langage Pascal, profitez de la version Academic (pour les étudiants, enseignants et établissements d'enseignement) ou Community Edition (gratuite pour une utilisation personnelle) [disponibles chez Embarcadero](https://www.embarcadero.com/products/delphi) (rubrique "outils gratuits"). En entreprise vous pouvez aussi tester Delphi avec la version d'évaluation ou celle de C++Builder si vous préférez coder en C/C++.

Une [formation complète aux bases du développement de logiciels](https://apprendre-delphi.fr/apprendre-la-programmation-avec-delphi-2020.php), utilisant le langage Pascal et Delphi, est disponible gratuitement. C'est la rediffusion de cours donnés en direct en 2020 pour une durée de presque 70 heures.

Une [prise en main de Delphi](https://apprendre-delphi.fr/prise-en-main-de-delphi.html) de quelques heures est aussi disponible si vous savez déjà développer et voulez juste les bases pour vous lancer dans la programmation en Pascal avec Delphi.

Pour aller plus loin vous pouvez aussi regarder les [rediffusions des conférences et présentations en ligne](https://apprendre-delphi.fr/points-techniques-et-presentations-en-francais.html) ou les [rediffusions de sessions de codage en direct de logiciels, applications mobiles et jeux vidéo](https://serialstreameur.fr).

Enfin, si vous préférez la lecture à la vidéo, vous trouverez tous les livres récents publiés sur Delphi et le langage Pascal sur [Delphi Books](https://delphi-books.com) et pouvez aussi consulter [mon blog sur le développement en Pascal](https://developpeur-pascal.fr).

Si vous avez besoin de cours sur le développement Delphi ou web, n'hésitez pas à [me contacter](https://vasur.fr/about). Je pourrai vous proposer des formations à la carte ou du mentoring s'il n'y a pas déjà des ressources en ligne selon votre besoin.

## Licence d'utilisation de ce dépôt de code et de son contenu

Ces codes sources sont distribués sous [licence MIT](LICENSE).

Vous êtes globalement libre d'utiliser le contenu de ce dépôt de code n'importe où à condition :
* d'en faire mention dans vos projets
* de diffuser les modifications apportées aux fichiers fournis dans ce projet sous licence MIT (en y laissant les mentions de copyright d'origine (auteur, lien vers ce dépôt, licence) obligatoirement complétées par les vôtres)
* de diffuser les codes sources de vos créations sous licence MIT

Ces codes sources sont fournis en l'état sans garantie d'aucune sorte.

Certains éléments inclus dans ce dépôt peuvent dépendre de droits d'utilisation de tiers (images, sons, ...). Ils ne sont pas réutilisables dans vos projets sauf mention contraire.

## Soutenez ce projet et son auteur

Si vous trouvez ce dépôt de code utile et voulez le montrer, merci de faire une donation [à son auteur](https://github.com/DeveloppeurPascal). Ca aidera à maintenir ce projet et tous les autres.

Vous pouvez utiliser l'un de ces services :

* [GitHub Sponsors](https://github.com/sponsors/DeveloppeurPascal)
* Ko-fi [en français](https://ko-fi.com/patrick_premartin_fr) ou [en anglais](https://ko-fi.com/patrick_premartin_en)
* [Patreon](https://www.patreon.com/patrickpremartin)
* [Liberapay](https://liberapay.com/PatrickPremartin)

Vous pouvez acheter une licence d'utilisateur pour [mes logiciels](https://lic.olfsoftware.fr/products.php?lng=fr) et [mes jeux vidéo](https://lic.gamolf.fr/products.php?lng=fr) ou [une licence de développeur pour mes bibliothèques](https://lic.developpeur-pascal.fr/products.php?lng=fr) si vous les utilisez dans vos projets.

Je suis également disponible en tant que prestataire pour vous aider à utiliser ce projet ou d'autres, comme pour vos développements de logiciels, applications mobiles et sites Internet. [Contactez-moi](https://vasur.fr/about) pour en discuter.
